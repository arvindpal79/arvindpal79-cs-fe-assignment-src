import { CloneDeepFormatterPipe } from './clone-deep-formatter.pipe';

describe('CloneDeepFormatterPipe', () => {
  it('create an instance', () => {
    const pipe = new CloneDeepFormatterPipe();
    expect(pipe).toBeTruthy();
  });
});
