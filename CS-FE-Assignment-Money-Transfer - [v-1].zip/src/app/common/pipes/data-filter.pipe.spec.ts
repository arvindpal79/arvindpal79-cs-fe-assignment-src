import { DataFilterPipe } from './data-filter.pipe';

describe('DataFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DataFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
