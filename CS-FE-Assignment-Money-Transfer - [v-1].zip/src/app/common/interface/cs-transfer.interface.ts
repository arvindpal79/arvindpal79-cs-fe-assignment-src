export interface CsTransfer {
}
